// Added Value Scorecard JS - by Kyle Okaly

$(document).ready(function() {
    var headerMenu = $('#menu'),
	    menuItemNum = headerMenu.children().length,
	    slider = $('#slider'),
	    sliderContainer = $('#slider-container'),
	    containerHeight = 474,
	    sliderBorders = $('#slider-borders'),
	    currentItemIndicator = $('<div class="current-menu-item"></div>'),
	    currentMenuItem = headerMenu.children().eq(0),
	    currentItemWidth = null,
	    listHeader = $('.list-header'),
        brandmonth = $('.monthDiff'),
        rightheader = $('.slider-headers-Panel-right'),
        listLogo = $('.list-Logo'),
	    footerInfo = $('.footer-info'),
        chartLogo = $('.Chartimg'),
        monthdiff = $('.monthDiff'),
        disclaimer = $('#disclaimer'),
	    //cardTitle =$('#card-title'),
        cardTitle =$('.card-title'),

	    //aboveInfo =$('#above-info'),
        aboveInfo =$('.above-info'),
        //body = $('#body'),
        body = $('#slider-container'),
        SlideArrow = $(".slide-arrow");
     
    triggerResizeEvent = true,
    currentSlide = null,
    currentSlideHeight = 0,
    slideNum = 0;
    mindex=0;
    $('#headerMobility').addClass('hidden');
	
    function insertCard(scriptId, data) {
        var source = $('#' + scriptId).get(0),
          template = Handlebars.compile(source.innerHTML),
          output = $(template(data));
        output.data('cardData', data);
        slider.append(output);
    }
    function updateInfo(dataSet) {
        $('.card-title').text(dataSet.cardTitle);
        //$('#card-title').text(dataSet.cardTitle);
        $('.above-info').text(dataSet.aboveInfo);
        $('#card-titlemobile').text(dataSet.cardTitle);
        $('#above-infomobile').text(dataSet.aboveInfo);
        //$('#difference').text(dataSet.difference);
        $('.brandMonth').text(dataSet.month);
        $('.difference').html(dataSet.difference);
        $('.diffMonth').text(dataSet.diffMonth);
        $('.MdiffMonth').text(dataSet.diffMonth);
        $('#time-period').text(dataSet.timePeriod);
        $('#disclaimer').text(dataSet.disclaimer);
        $('.MbrandMonth').text(dataSet.month);
        $('.Mdifference').html(dataSet.difference);
    }
    function updateMenuItemIndicator(indicator, newItem) {
        currentItemWidth = newItem.width();
		//console.log( "currentItemWidth=" + currentItemWidth);
		
        var newItemLeft = newItem.position().left + headerMenu.position().left,
            newItemRight = $('#wrap').width() - (newItemLeft + currentItemWidth);
       // alert(newItem.width());
        //alert(mindex);
		//console.log( "wrap width=" + $('#wrap').width());

		
        //if (newItem.width() > 65 && newItem.width() < 78 && mindex == 0) {
          //newItemRight = 447;
        //}
        //if (newItem.width() > 41 && newItem.width() < 50 && mindex == 0) {
          //  newItemRight = 321.46875;
        //}
        indicator.width(currentItemWidth).css('right', newItemRight);


    }
    insertCard('info-template', dataCore);
    insertCard('info-template', dataSecondary);
    insertCard('info-Chart', dataChart);
    insertCard('info-mobility', datamobility);
    insertCard('summary-template', dataSummary);
    updateInfo(dataCore);
	
    updateMenuItemIndicator(currentItemIndicator, currentMenuItem);
    currentItemIndicator.appendTo('#header');
	
    var swipeObject = new Swipe(sliderContainer.get(0), {
        callback: function(index, el) {
            mindex=index;
            currentSlide = $(el);
            currentSlideHeight = currentSlide.height();
            slider.height(currentSlideHeight);
            sliderContainer.stop(true,true).animate({
                scrollTop: 0,
            }, 200);
            var borderColor = null,
                scrollable = null,
                menuItem = headerMenu.children().eq(index);
            if (el.tagName.toLowerCase() == 'ul') {
                borderColor = '#e1e1e1';
                listHeader.removeClass('hidden');
                listLogo.removeClass('hidden');
                footerInfo.removeClass('hidden');
                brandmonth.removeClass('hidden');
                rightheader.removeClass('hidden');
         
            }
            else {
                borderColor = '#fff';
                //listHeader.addClass('hidden');
                brandmonth.addClass('hidden');
                rightheader.addClass('hidden');
                listLogo.addClass('hidden');
                disclaimer.addClass('hidden');
                //footerInfo.addClass('hidden');
            }

            if (index == 2 || index==4) {
	      
                disclaimer.addClass('hidden');
            }
            else{
                disclaimer.removeClass('hidden');
            }
            if (index == 2) {
                chartLogo.removeClass('Chartimg');
                monthdiff.addClass('hidden');
                disclaimer.removeClass('hidden');
                $('#At').addClass('At');
                $('#Verizon').addClass('Verizon');
                $('#Netcabel').addClass('Netcabel');
            }
            else {
                chartLogo.addClass('Chartimg');
                monthdiff.removeClass('hidden');
                aboveInfo.removeClass('hidden');
                $('#At').removeClass('At');
                $('#Verizon').removeClass('Verizon');
                $('#Netcabel').removeClass('Netcabel');
            }
	    
            if (index == 3) {

                $('#headerMobility').removeClass('hidden');
                $('#headerothers').addClass('hidden');

            }
            else {
                $('#headerMobility').addClass('hidden');
                $('#headerothers').removeClass('hidden');
            }
            sliderBorders.css({
                borderLeftColor: borderColor,
                borderRightColor: borderColor,
                height: Math.min(currentSlideHeight, containerHeight) - 4
            });
            if (!menuItem.length) {  // Swipe.js duplicates slides when there are only 2
                var numSlides = currentSlide.parent().children().length;
                menuItem = headerMenu.children().eq(index - numSlides);
                if (!menuItem.length) return;
            }
            currentMenuItem = menuItem;
            currentMenuItem.addClass('on').siblings().removeClass('on');
            updateInfo(currentSlide.data('cardData'));
            updateMenuItemIndicator(currentItemIndicator, currentMenuItem);
        }
    });
	
    $('a.slide-arrow.left').click(function(e) {
        e.preventDefault();
        slideNum--;
        if (slideNum < 0) slideNum = menuItemNum - 1;
        swipeObject.slide(slideNum);
        var slideHeight = currentSlide.height();
        if (slideHeight > 438) {
            slideHeight = 439;
        }
        body.height(30 + slideHeight);
        sliderBorders.height(25 + slideHeight);
        var px = (slideHeight - (slideHeight/2.5)) ;
    	
        if (mindex == 4) {
            px=px+60+"px"
            SlideArrow.css('top',px);
        }
        if (mindex == 3) {
            px = px + 50 + "px"
            SlideArrow.css('top', px);
        }
        else
        {
            px=px+20+"px"
            SlideArrow.css('top',px);
        }
	 
    });
    $('a.slide-arrow.right').click(function(e) {
        e.preventDefault();
        slideNum++;
        if (slideNum > menuItemNum - 1) slideNum = 0;
        swipeObject.slide(slideNum);
        var slideHeight = currentSlide.height();
        if (slideHeight > 438) {
            slideHeight =439;
        }
        body.height(30 + slideHeight);
        sliderBorders.height(25 + slideHeight);
        var px = (slideHeight - (slideHeight/2.5)) ;
    	
        if (mindex == 4) {
            px=px+60+"px"
            SlideArrow.css('top',px);
        }
        if (mindex == 3) {
            px = px + 50 + "px"
            SlideArrow.css('top', px);
        }
        else
        {
            px=px+20+"px"
            SlideArrow.css('top',px);
        }
    });
	
    headerMenu.find('a').click(function(e) {
        e.preventDefault();
        var menuItem = $(this).parent();
        menuItem.siblings().removeClass('on');
        menuItem.addClass('on');
        slideNum = menuItem.index();
        swipeObject.slide(slideNum);
        var slideHeight = currentSlide.height();
        if (slideHeight > 438) {
            slideHeight = 439;
        }
        body.height(30+slideHeight);

        sliderBorders.height(25 + slideHeight);

        var px = (slideHeight - (slideHeight/2.5)) ;
    	
        if (mindex == 4 ) {
            px=px+60+"px"
            SlideArrow.css('top',px);
        }

        if (mindex == 3) {
            px = px + 50 + "px"
            SlideArrow.css('top', px);
        }
        else
        {
            px=px+20+"px"
            SlideArrow.css('top',px);
        }
    });


    $(window).resize(function() {
      if (triggerResizeEvent) {
  	  triggerResizeEvent = false;
  	  setInterval(function() {triggerResizeEvent = true;}, 250);  // Trigger no more than once per quarter-second when resizing
  	  if (currentItemWidth != currentMenuItem.width() && $(window).width() > 650) {
  	    //updateMenuItemIndicator(currentItemIndicator, currentMenuItem);
		setInterval(function() {updateMenuItemIndicator(currentItemIndicator, currentMenuItem);}, 250);
  	  }
  	   }
  });

	
});
