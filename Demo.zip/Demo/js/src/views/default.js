define([
	//'backbone'
	//'views/scoreCardsView'
    
], function (

	//Backbone
	//ScorecardsView

) {

	var DefaultView = Backbone.View.extend({

		  el: null
		, scorecardsView: null

		, initialize: function () {
			this.$el = $('body');
			console.log('defaultView.initialize: ', this.$el);
			
			//this.scorecardsView = new ScorecardsView
			//this.$el.append(this.scorecardsView.$el);
		}

		, render: function () {

			//this.scorecardsView.render();

			return this.$el;
		}

	});

	var defaultView = new DefaultView;

	return defaultView;
});