define([], function () {

    var Dealer = function () {

		console.log('dealer initialized.');
    };

    // Dealer.prototype.getData = function() {
    // 	console.log('app.getData invoked');
    // };

    return Dealer;
});