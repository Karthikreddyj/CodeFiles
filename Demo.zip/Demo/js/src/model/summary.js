define([], function() {
	var SummaryModel = function() {

	};

	return SummaryModel;
});