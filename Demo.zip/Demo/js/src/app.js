define([], function () {

    var Application = function () {

		console.log('app initialized.');
    };

    Application.prototype.getData = function() {
    	console.log('app.getData invoked');
    };

    return Application;
});