requirejs.config({

    // Defines the base URL for Javascript files
    // The URL is relative to the main index.html page
    baseUrl: ''

    // Defines aliases for common Javascript files/modules
    , paths: {

        //app infrastructure
        // 'text': 'js/lib/require/require-text.min'
        // , 'd3': 'js/lib/d3/d3.v2'
        // , 'jquery': 'js/lib/jquery/jquery.min'

        // RequireJS plugins
          text: 'js/lib/require/require-text.min'
        , css: 'js/lib/require/require-css.min'

        // Core libraries
        // , modernizr: 'libs/modernizr/modernizr-2.6.1.min'
        , jquery: 'js/lib/jquery/jquery.min'
        , underscore: 'js/lib/underscore/underscore-1.3.3.min'
        , backbone: 'js/lib/backbone/backbone-0.9.2.min'
        

        // Additional libraries aliases
        //, jqueryui: 'js/lib/jquery/jqueryui/jquery-ui-1.8.23.min'
        // , bootstrap: 'libs/bootstrap/bootstrap-2.1.0.min'
         , handlebars: 'js/lib/handlebars/handlebars-1.0.0.beta.6.min'
  
        //application
        , 'app': 'js/src/app'
    }

    // Defines dependencies (effectively sets the loading orders)
    , shim: {
        'backbone': ['jquery', 'underscore']
        , 'app': ['text', 'jquery', 'underscore', 'backbone', 'handlebars']
    }

});

// Activates application module
require(['app'], function(Application) { 
    new Application(); 
});