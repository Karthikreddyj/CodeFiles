var dataCore = {
    aboveInfo: "April 2014"
	, cardTitle: "Core Customer Journey"
	, month: "Apr'14"
    , difference: "&#x25B3; from"
	, diffMonth: "Mar'14"
	, items: [
		{
		    color: "grey"
			, measureText: "Unaided Awareness"
            ,submeasureText:""
            , Brand1color: "grey"
			, observedValue: "70%"
			, predictedValue: "-1"
            , Brand2color: "grey"
            , MyobservedValue: "51%"
			, MypredictedValue: "+3"
            , Brand3color: "grey"
            , MyobservedValueNet: "33%"
			, MypredictedValueNet: "-3"

		}
		, {
		    color: "grey"
			, measureText: "Aided Awareness"
            , submeasureText: ""
            , Brand1color: "grey"
			, observedValue: "96%"
			, predictedValue: "--"
            , Brand2color: "grey"
            , MyobservedValue: "94%"
			, MypredictedValue: "-1"
            , Brand3color: "grey"
            , MyobservedValueNet: "93%"
			, MypredictedValueNet: "-1"
		}
		, {
		    color: "grey"
			, measureText: "Brand Familiarity"
            , submeasureText: "(know a lot/very well)"
            , Brand1color: "grey"
			, observedValue: "69%"
			, predictedValue: "--"
            , Brand2color: "green"
            , MyobservedValue: "61%"
			, MypredictedValue: "+7"
            , Brand3color: "grey"
            , MyobservedValueNet: "35%"
			, MypredictedValueNet: "+3"
		}
		, {
		    color: "grey"
			, measureText: "Brand Consideration"
            , submeasureText: "(only one/consider above most others)"
            , Brand1color: "grey"
			, observedValue: "46%"
			, predictedValue: "--"
            , Brand2color: "grey"
            , MyobservedValue: "47%"
			, MypredictedValue: "+2"
            , Brand3color: "grey"
            , MyobservedValueNet: "21%"
			, MypredictedValueNet: "+3"
		}
		, {
		    color: "grey"
			, measureText: "Claimed Telecom/Technology Solutions Provider"
            , submeasureText: ""
            , Brand1color: "grey"
			, observedValue: "38%"
			, predictedValue: "--"
            , Brand2color: "grey"
            , MyobservedValue: "19%"
			, MypredictedValue: "--"
            , Brand3color: "grey"
            , MyobservedValueNet: "25%"
			, MypredictedValueNet: "--"
		}
    	
     
	]
	, timePeriod: "Apr'14 (03/31/14 - 05/04/14)"
	, disclaimer: "Green/Red Color indicates significant difference vs. Mar' 14 at 95% confidence level"
}