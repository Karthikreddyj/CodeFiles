﻿var datamobility = {
    aboveInfo: "April 2014"
	, cardTitle: "Mobility Metrics"
	, month: "Apr'14"
    , difference: "&#x25B3; from"
    , diffMonth: "Mar'14"
	, items: [
		{
		    color: "grey"
			, measureText: "Unaided Provider Awareness"
            , submeasureText: ""
            , Brand1color: "grey"
			, observedValue: "68%"
			, predictedValue: "-4"
            , Brand2color: "grey"
            , MyobservedValue: "71%"
			, MypredictedValue: "--"
            , Brand3color: "red"
            , MyobservedValueNet: "41%"
			, MypredictedValueNet: "-10"
            , Brand4color: "grey"
            , MyobservedValueNet1: "36%"
			, MypredictedValueNet1: "-5"

		}
		, {
		    color: "grey"
			, measureText: "Unaided Provider Preference"
            , submeasureText: ""
            , Brand1color: "grey"
			, observedValue: "34%"
			, predictedValue: "-1"
            , Brand2color: "grey"
            , MyobservedValue: "39%"
			, MypredictedValue: "+6"
            , Brand3color: "grey"
            , MyobservedValueNet: "7%"
			, MypredictedValueNet: "-2"
            , Brand4color: "grey"
            , MyobservedValueNet1: "6%"
			, MypredictedValueNet1: "-1"
		}

	]
	, timePeriod: "Apr'14 (03/31/14 - 05/04/14)"
	, disclaimer: "Green/Red Color indicates significant difference vs. Mar' 14 at 95% confidence level"
}