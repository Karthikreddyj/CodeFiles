var dataSummary = {
    aboveInfo: "April 2014"
    , cardTitle: "Summary"
  , summaryHeader: ""
	, summaryContent: [
		"AT&T maintains on Core and Secondary measures in April. Gains for Verizon in Core and Secondary measures bring them back to benchmark levels."
	]
}