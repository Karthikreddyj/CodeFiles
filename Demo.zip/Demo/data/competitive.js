var dataCompetitive = {
	monthAndYear: "JANUARY 2013"
	, cardTitle: "COMPETITIVE"
	, cardLegend01: "OBSERVED"
	, cardLegend02: "MONTH PRIOR" 
	, competitors : ["SPIRIVA", "ADVAIR", "SYMBICORT"]
	, items: [
		{	measureText: "Unaided ad awareness"
		 	, arrowColor: "blue"
		 	, columns : [
		 	 	{	color: "blue"
		 	 	 	, arrow: 'neutral'
		 	 	 	, observedValue: "24%"
		 	 	 	, predictedValue: "+2%"
		 	 	}
		 	 	, {	color: "blue"
		 	 	   	, arrow: 'neutral'					
		 	 	   	, observedValue: "30%"
		 	 	   	, predictedValue: "+6%"
		 	 	}
		 	 	, {	color: "blue"
		 	 	   	, arrow: 'neutral'					
		 	 	   	, observedValue: "12%"
		 	 	   	, predictedValue: "-2%"
		 	 	}
		 	]		
		 	
		}
		, {	measureText: "Total unaided brand awareness"
		   	, arrowColor: "blue"
		   	, columns : [
		   	 	{	color: "blue"
		   	 	 	, arrow: 'neutral'
		   	 	 	, observedValue: "31%"
		   	 	 	, predictedValue: "-1%"
		   	 	}
		   	 	, {	color: "blue"
		   	 	   	, arrow: 'neutral'					
		   	 	   	, observedValue: "37%"
		   	 	   	, predictedValue: "+5%"
		   	 	}
		   	 	, {	color: "blue"
		   	 	   	, arrow: 'neutral'					
		   	 	   	, observedValue: "17%"
		   	 	   	, predictedValue: "-1%"
		   	 	}
		   	]		
		   	
		}
		, {	measureText: "Total ad awareness"
		   	, arrowColor: "blue"
		   	, columns : [
		   	 	{	color: "blue"
		   	 	 	, arrow: 'neutral'
		   	 	 	, observedValue: "66%"
		   	 	 	, predictedValue: "+4%"
		   	 	}
		   	 	, {	color: "blue"
		   	 	   	, arrow: 'neutral'					
		   	 	   	, observedValue: "71%"
		   	 	   	, predictedValue: "+2%"
		   	 	}
		   	 	, {	color: "blue"
		   	 	   	, arrow: 'neutral'					
		   	 	   	, observedValue: "52%"
		   	 	   	, predictedValue: "-7%"
		   	 	}
		   	]		
		   	
		}
		, {	measureText: "Total brand awareness"
		   	, arrowColor: "blue"
		   	, columns : [
		   	 	{	color: "blue"
		   	 	 	, arrow: 'neutral'
		   	 	 	, observedValue: "86%"
		   	 	 	, predictedValue: "+2%"
		   	 	}
		   	 	, {	color: "blue"
		   	 	   	, arrow: 'neutral'					
		   	 	   	, observedValue: "89%"
		   	 	   	, predictedValue: "-3%"
		   	 	}
		   	 	, {	color: "blue"
		   	 	   	, arrow: 'neutral'					
		   	 	   	, observedValue: "82%"
		   	 	   	, predictedValue: "-3%"
		   	 	}
		   	]		
		   	
		}
		, {	measureText: "Total CtA"
		   	, arrowColor: "blue"
		   	, columns : [
		   	 	{	color: "blue"
		   	 	 	, arrow: 'neutral'
		   	 	 	, observedValue: "34%"
		   	 	 	, predictedValue: "+2%"
		   	 	}
		   	 	, {	color: "blue"
		   	 	   	, arrow: 'neutral'					
		   	 	   	, observedValue: "36%"
		   	 	   	, predictedValue: "+1%"
		   	 	}
		   	 	, {	color: "blue"
		   	 	   	, arrow: 'neutral'					
		   	 	   	, observedValue: "37%"
		   	 	   	, predictedValue: "+5%"
		   	 	}
		   	]		
		   	
		}
		, {	measureText: "Opens restricted airways"
		   	, arrowColor: "blue"
		   	, columns : [
		   	 	{	color: "blue"
		   	 	 	, arrow: 'neutral'
		   	 	 	, observedValue: "75%"
		   	 	 	, predictedValue: "+1%"
		   	 	}
		   	 	, {	color: "blue"
		   	 	   	, arrow: 'neutral'					
		   	 	   	, observedValue: "76%"
		   	 	   	, predictedValue: "+7%"
		   	 	}
		   	 	, {	color: "blue"
		   	 	   	, arrow: 'neutral'					
		   	 	   	, observedValue: "75%"
		   	 	   	, predictedValue: "+3%"
		   	 	}
		   	]		
		   	
		}
		, {	measureText: "Allows you to breathe easier"
		   	, arrowColor: "blue"
		   	, columns : [
		   	 	{	color: "blue"
		   	 	 	, arrow: 'neutral'
		   	 	 	, observedValue: "82%"
		   	 	 	, predictedValue: "+8%"
		   	 	}
		   	 	, {	color: "blue"
		   	 	   	, arrow: 'neutral'					
		   	 	   	, observedValue: "77%"
		   	 	   	, predictedValue: "0%"
		   	 	}
		   	 	, {	color: "blue"
		   	 	   	, arrow: 'neutral'					
		   	 	   	, observedValue: "75%"
		   	 	   	, predictedValue: "-4%"
		   	 	}
		   	]		
		   	
		}
		, {	measureText: "Reduces flare-ups / exacerbations"
		   	, arrowColor: "blue"
		   	, columns : [
		   	 	{	color: "blue"
		   	 	 	, arrow: 'neutral'
		   	 	 	, observedValue: "69%"
		   	 	 	, predictedValue: "+5%"
		   	 	}
		   	 	, {	color: "green"
		   	 	   	, arrow: 'up'					
		   	 	   	, observedValue: "68%"
		   	 	   	, predictedValue: "+15%"
		   	 	}
		   	 	, {	color: "blue"
		   	 	   	, arrow: 'neutral'					
		   	 	   	, observedValue: "62%"
		   	 	   	, predictedValue: "+3%"
		   	 	}
		   	]		
		   	
		}
	]
	, timePeriod: "Calendar Month (1/2/13 - 1/31/13)"
	, disclaimer: "Arrow indicates significant difference at a 95% level of confidence versus previous month"
}