﻿
var dataChart = {
    aboveInfo: "April 2014"
  , cardTitle: "Value Proposition/Imagery"
  , month: "Apr'14"
  , difference: "&#x25B3; from"
  , diffMonth: "Mar'14"
  , timePeriod: "Apr'14 (03/31/14 - 05/04/14)"
  , disclaimer: ""
}
var minvalUp;
var maxvalUp;
minvalUp = 0;
maxvalUp = 7;

$(function () {

    //Note: We displayed chart in Web as invertable i.e., X-axis act as Y and Y-axis act as X
    var chartTitle = "Value Proposition/Imagery"
    //For displaying X-axis Labels
    var xaxisLabels;

    //For Displaying X-axis Opposite Labels
    //Data for AT&T  right side
    var xaxisLabelsOpp = ['61%', '53%', '53%', '81%', '50%', '63%', '42%', '49%', '38%', '43%', '58%', '58%', '56%', '68%', '60%', '67%', '63%', '66%', '57%', '52%', '56%', '45%', '50%', '50%']
    //Data for AT&T
    var ATTData = [[61], [53], [53], [81], [50], [63], [42], [49], [38], [43], [58], [58], [56], [68], [60], [67], [63], [66], [57], [52], [56], [45], [50], [50]]

    //Data for Verizon
    var VerizonData = [[60], [48], [45], [69], [47], [66], [37], [46], [27], [33], [50], [50], [40], [61], [44], [58], [61], [61], [49], [47], [49], [41], [49], [48]]

    //Data for NetCabel
    var NetCabelData = [[38], [36], [36], [58], [39], [42], [27], [36], [25], [27], [45], [40], [36], [48], [35], [49], [42], [41], [44], [40], [36], [34], [30], [28]]

    // scroll up and down
    $("#scrollup").click(function () {
        if (maxvalUp != ATTData.length - 1) {
            minvalUp = minvalUp + 8;
            maxvalUp = maxvalUp + 8;

            var chartup = $('#container').highcharts();
            if (maxvalUp >= ATTData.length) {
                maxvalUp = ATTData.length - 1;
                minvalUp = minvalUp;
            }
            chartup.xAxis[0].setExtremes(minvalUp, maxvalUp, true);
        }

    });
    $("#scrolldown").click(function () {
        if (maxvalUp != 8) {
            minvalUp = minvalUp - 8;
            maxvalUp = maxvalUp - 8;

            var chartup = $('#container').highcharts();
            if (maxvalUp <= 8) {
                maxvalUp = 7;
                minvalUp = 0;
            }
            chartup.xAxis[0].setExtremes(minvalUp, maxvalUp, true);
        }

    });

    var bodywidth;
    var chartmarginleft;
    var xAxisXvalue;
    var yAxisWidth;
    var subtitleXvalue;
    var xAxisoppositeXvalue;
    var truefalse;
    var imageAT;
    var imageVZ;
    var imageNC;
    var subtitleYvalues;

    bodywidth = $('#body').width();
    //alert(bodywidth);

    if (bodywidth < 500) {
        chartmarginleft = 170;
        xAxisXvalue = -160;
        yAxisWidth = 100;
        subtitleXvalue = -30;
        xAxisoppositeXvalue = -55   ;
        truefalse = false;
        imageAT = 'url(img/mobile-at-chart-icon.png)';
        imageVZ = 'url(img/mobile-verizon-chart-icon.png)';
        imageNC = 'url(img/mobile-netcable-chart-icon.png)';
        subtitleYvalues = 40;
        xaxisLabels = ['Expert and thought leader', 'Delivers on its promises', 'Secure technology/network', 'Stable, solid company', 'Dedicated to its customers', 'Is innovative', 'Help transform my business',
                                  'Improve business operation', 'Has business understanding', 'Has industry understanding', 'Custom/tailored solutions', 'Configure solutions', 'Integrate solutions', 'Scale to service my needs', 'Has right partners',
                                  'Relevant products/svcs', 'Is a brand I can rely on', 'Advancing future tech', 'Brand would most research', 'Easy to do business with', 'Improving way we connect', 'Good value for the money',
                                  'Disappointed if brand gone', 'Best brand versus others']

    }
    else if (bodywidth >= 500 && bodywidth < 760) {
        chartmarginleft = 200;
        xAxisXvalue = -200;
        yAxisWidth = 280;
        subtitleXvalue = 7;
        xAxisoppositeXvalue = 0;
        truefalse = false;
        imageAT = 'url(img/at-chart-icon.png)';
        imageVZ = 'url(img/verizon-chart-icon.png)';
        imageNC = 'url(img/netcable-chart-icon.png)';
        subtitleYvalues = 17;
        xaxisLabels = ['Expert and thought leader', 'Delivers on its promises', 'Secure technology/network', 'Stable, solid company', 'Dedicated to its customers', 'Is innovative', 'Help transform my business',
                                      'Improve business operation', 'Has business understanding', 'Has industry understanding', 'Custom/tailored solutions', 'Configure solutions', 'Integrate solutions', 'Scale to service my needs', 'Has right partners',
                                      'Relevant products/svcs', 'Is a brand I can rely on', 'Advancing future tech', 'Brand would most research', 'Easy to do business with', 'Improving way we connect', 'Good value for the money',
                                      'Disappointed if brand gone', 'Best brand versus others']
    }
    else {
        chartmarginleft = 240;
        xAxisXvalue = -240;
        yAxisWidth = 300;
        subtitleXvalue = 7;
        xAxisoppositeXvalue = 0;
        truefalse = false;
        imageAT = 'url(img/at-chart-icon.png)';
        imageVZ = 'url(img/verizon-chart-icon.png)';
        imageNC = 'url(img/netcable-chart-icon.png)';
        subtitleYvalues = 17;
        xaxisLabels = ['Expert and thought leader', 'Delivers on its promises', 'Secure technology/network', 'Stable, solid company', 'Dedicated to its customers', 'Is innovative', 'Help transform my business',
                            'Improve business operation', 'Has business understanding', 'Has industry understanding', 'Custom/tailored solutions', 'Configure solutions', 'Integrate solutions', 'Scale to service my needs', 'Has right partners',
                            'Relevant products/svcs', 'Is a brand I can rely on', 'Advancing future tech', 'Brand would most research', 'Easy to do business with', 'Improving way we connect', 'Good value for the money',
                            'Disappointed if brand gone', 'Best brand versus others']
    }
    chart = new Highcharts.Chart({
        chart: {
            renderTo: 'container',
            type: 'spline',
            //zoomType: 'xy',
            inverted: true,
            //width: 580,
            marginLeft: chartmarginleft,
            //marginTop: 20,
            //marginBottom: 10

            
        },
        title: {
            text: '',
            align: 'left',
            y: 40
        },
        scrollbar: {
            enabled: false
        },
        tooltip: {
            pointFormat: '{series.name}:{point.y}{point.percentage}%',
            percentageDecimals: 0,
            borderWidth: 1,
            shadow: false,
            shape: 'square'
        },

        credits: {
            enabled: false
        },
        subtitle: {
            text: 'AT&T',
            align: 'right',
            y: subtitleYvalues,
            x: subtitleXvalue

        },
        xAxis: [{

            categories: xaxisLabels,
            min: 0, 
            max: 7,
            gridLineWidth: 0,
            lineWidth: 0,
            opposite: false,
            lineWidth: 0,
            tickLength: 0,

            labels: {
                align: 'left',
                x: xAxisXvalue,
                style: {

                    //width: 240,
                }
            },
        },
                {
                    linkedTo: 0,
                    opposite: true,
                    categories: xaxisLabelsOpp,
                    gridLineWidth: 0,
                    lineWidth: 0,
                    tickLength: 0,
                    labels: {
                        x: xAxisoppositeXvalue,
                        style: {
                            color: '#5882FA',
                            font: '11px Trebuchet MS, Verdana, sans-serif'
                        }
                    },

                }

        ],
        yAxis: [{ // Primary yAxis
            min: 0,
            max: 90,
            tickInterval: 45,
            gridLineWidth: 0,
            width: yAxisWidth,
            x: 340,
            lineWidth: 2,
            lineColor: '#BDBDBD',
            reversed: false,
            allowDecimals: false,
            labels: {

                style: {
                    color: '#BDBDBD',
                    font: '13px Helvetica',
                    fontWeight: 'bold'

                }
            },
            title: {
                text: '',
                style: {
                    color: '#89A54E'
                }
            },

            opposite: truefalse

        }, { // Secondary yAxis
            min: 0,


            title: {
                text: '',
                style: {
                    color: '#4572A7'
                }
            },
            labels: {
                formatter: function () {
                    return this.value + ' mm';
                },
                style: {
                    color: '#4572A7'
                }
            },
            opposite: true

        }, { // Tertiary yAxis
            gridLineWidth: 0,
            title: {
                text: '',
                style: {
                    color: '#AA4643'
                }
            },
            labels: {
                formatter: function () {
                    return this.value + ' mb';
                },
                style: {
                    color: '#AA4643'
                }
            },
            opposite: true
        }],

        legend: {
            layout: 'horizontal',
            align: 'center',
            verticalAlign: 'top',
            borderWidth: 0,
            itemDistance: 50,
            enabled: false
        },

        series: [
                    {
                        name: 'Net-Cable',
                        data: NetCabelData,
                        lineWidth: 0,
                        marker: {
                            fillColor: 'Green',
                            enabled: true,
                            radius: 6,
                            symbol: imageNC
                        },
                        color: 'green'
                    },
                                        {
                        name: 'Verizon',
                        data: VerizonData,
                        lineWidth: 0,
                        marker: {
                            fillColor: 'C00000',
                            enabled: true,
                            radius: 7,
                            symbol: imageVZ
                        },
                        color: {
                            linearGradient: { x1: 192, x2: 0, y1: 0, y1: 1 },
                            stops:[
                                        [0,'rgb(192,0,0)'],
                                        [1,'rgb(192,0,0)']
                                  ]
                        },
                    },

                    {
                        name: 'AT&T',
                        data: ATTData,
                        lineWidth: 0.8,
                        x: 10,
                        marker: {
                            fillColor: 'red',
                            radius: 5,
                            symbol: imageAT

                        },
                        color: '#5882FA'
                    },



        ]



    });
});