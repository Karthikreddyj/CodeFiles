var dataSecondary = {
    aboveInfo: "April 2014"
	, cardTitle: "Secondary Customer Journey"
	, month: "Apr'14"
    , difference: "&#x25B3; from"
    , diffMonth: "Mar'14"
	, items: [
		{
		    color: "grey"
			, measureText: "Brand Preference Chosen Today"
            , submeasureText: "(strongly/somewhat agree)"
            , Brand1color: "grey"
			, observedValue: "63%"
			, predictedValue: "+3"
            , Brand2color: "green"
            , MyobservedValue: "65%"
			, MypredictedValue: "+8"
            , Brand3color: "grey"
            , MyobservedValueNet: "31%"
			, MypredictedValueNet: "+2"

		}
		,{
		    color: "grey"
			, measureText: "Purchase Interest Next Time Given The Choice"
            , submeasureText: "(strongly/somewhat agree)"
            , Brand1color: "grey"
			, observedValue: "59%"
			, predictedValue: "-1"
            , Brand2color: "green"
            , MyobservedValue: "64%"
			, MypredictedValue: "+10"
            , Brand3color: "grey"
            , MyobservedValueNet: "29%"
			, MypredictedValueNet: "+3"

		}
        ,{
		    color: "grey"
			, measureText: "Most Preferred Brand"
            , submeasureText: "(Unaided)"
            , Brand1color: "grey"
			, observedValue: "33%"
			, predictedValue: "+6"
            , Brand2color: "grey"
            , MyobservedValue: "20%"
			, MypredictedValue: "+2"
            , Brand3color: "grey"
            , MyobservedValueNet: "12%"
			, MypredictedValueNet: "-3"

		}
	]
	, timePeriod: "Apr'14 (03/31/14 - 05/04/14)"
	, disclaimer: "Green/Red Color indicates significant difference vs. Mar' 14 at 95% confidence level"
}