﻿var dataChart = {
   aboveInfo: "February 2014"
, cardTitle: "Value Proposition/Imagery"
, month: "Feb'14"
   , difference: "&#x25B3; from<br> Jan'14"
, timePeriod: "Feb'14 (02/02/14 - 03/01/14)"
, disclaimer: "Green/Red Color indicates significant difference vs. Dec 13 at 95% confidence level"
}
$(function () {

    //Note: We displayed chart in Web as invertable i.e., X-axis act as Y and Y-axis act as X
    var chartTitle="Value Proposition/Imagery"
    //For displaying X-axis Labels
    var xaxisLabels = ['Is committed to advancing the future of technology', 'Is constantly improving the way businesses connect', 'Gives my company good value for the money', 'Is easy to do business with', 'Is a brand I can rely on', 'If this brand was taken off the market, my co. would be very disappointed',
                'Is the best brand compared to others', 'Is a brand I would most want to research for future Telecom/Tech solutions', 'Offers products and services which are relevant to my business']

    //For Displaying X-axis Opposite Labels
    var xaxisLabelsOpp = ['56%', '51%', '40%', '45%', '56%', '43%', '41%', '49%', '57%']

    //For Showing x-axis Opposite Label We Map this empty data to X-axis Opposite
    var EmptyData = [[0], [0], [0], [0], [0], [0], [0], [0], [0]]

    //Data for AT&T
    var ATTData = [[56], [51], [40], [45], [56], [43], [41], [49], [57]]

    //Data for Verizon
    var VerizonData = [[65], [58], [50], [70], [73], [55], [48], [63], [65]]

    //Data for NetCabel
    var NetCabelData = [[45], [35], [28], [32], [38], [25], [25], [35], [45]]

    var bodywidth;
    var chartmarginleft;
    var xAxisXvalue;
    var yAxisWidth;
    var subtitleXvalue;
    var xAxisoppositeXvalue;
    var truefalse;
        bodywidth = $('#body').width();
        if (bodywidth < 350) {
            chartmarginleft = 100;
            xAxisXvalue = -100;
            yAxisWidth = 150;
            subtitleXvalue = -40;
            xAxisoppositeXvalue = -65;
            truefalse = true;
        }
        else {
            chartmarginleft = 240;
            xAxisXvalue = -240;
            yAxisWidth = 300;
            subtitleXvalue = 7;
            xAxisoppositeXvalue = 0;
            truefalse = false;
        }

    // if user wants to test in web browers by resizing the brower the below code will apply   
        //$(window).resize(function () {
            
        //    bodywidth = $('#body').width();
          
        //    if (bodywidth < 350) {
            
        //        chartmarginleft = 100;
        //        xAxisXvalue = -100;
        //        yAxisWidth = 150;
        //        subtitleXvalue = -40;
        //        xAxisoppositeXvalue = -65;
        //    }
        //    else {
              
        //        chartmarginleft = 240;
        //        xAxisXvalue = -240;
        //        yAxisWidth = 300;
        //        subtitleXvalue = 7;
        //        xAxisoppositeXvalue = 0;
        //    }

        //});
    // this will work for mobile view directly.

    chart = new Highcharts.Chart({
        chart: {
            renderTo: 'container',
            type: 'spline',
            zoomType: 'xy',
            inverted: true,
            //width: 580,
            marginLeft: chartmarginleft
        },
        title: {
            text: '',
            align: 'left',
            y: 40
        },

        subtitle: {
            text: 'AT&T',
            align: 'right',
            y: 40,
            x: subtitleXvalue

        },
        xAxis: [{

            categories: xaxisLabels,
            gridLineWidth: 0,
            lineWidth: 0,
            opposite: false,
              lineWidth: 0,
           tickLength: 0,
            labels: {
                align: 'left',
                x: xAxisXvalue,
                style: {
                   
                    //width: 240,
                }
            },
        },
                {
                    opposite: true,
                    categories: xaxisLabelsOpp,
                    gridLineWidth: 0,
                    lineWidth: 0,
                    tickLength: 0,
                    labels: {
                        x: xAxisoppositeXvalue,
                        style: {
                            color: '#5882FA',
                            font: '11px Trebuchet MS, Verdana, sans-serif'
                        }
                    },

                }
        ],
        yAxis: [{ // Primary yAxis
            min: 0,
            max: 90,
            tickInterval: 45,
            gridLineWidth: 0,
            width: yAxisWidth,
            //x: -240,
            lineWidth: 2,
            lineColor: '#BDBDBD',
            reversed: false,
            allowDecimals: false,
            labels: {
            
                style: {
                    color: '#BDBDBD',
                    font: '13px Helvetica',
                    fontWeight: 'bold'
                   
                }
            },
            title: {
                text: '',
                style: {
                    color: '#89A54E'
                }
            },

            opposite: truefalse

        }, { // Secondary yAxis
            min: 0,


            title: {
                text: '',
                style: {
                    color: '#4572A7'
                }
            },
            labels: {
                formatter: function () {
                    return this.value + ' mm';
                },
                style: {
                    color: '#4572A7'
                }
            },
            opposite: true

        }, { // Tertiary yAxis
            gridLineWidth: 0,
            title: {
                text: '',
                style: {
                    color: '#AA4643'
                }
            },
            labels: {
                formatter: function () {
                    return this.value + ' mb';
                },
                style: {
                    color: '#AA4643'
                }
            },
            opposite: true
        }],

        legend: {
            layout: 'horizontal',
            align: 'center',
            verticalAlign: 'top',
            borderWidth: 0,
            itemDistance: 50,
            enabled: false
        },

        series: [
                 {
                     name: 'AT&T',
                     data: ATTData,
                     lineWidth: 0.8,
                     x: 10,
                     marker: {
                         fillColor: 'red',
                         radius: 5,
                         symbol: 'url(img/at-chart-icon.png)'

                     },
                     color: '#5882FA'
                 },

    {
        linkedTo: 'id-1',
        xAxis: 1,

        data: EmptyData,
        lineWidth: 0,
        marker: {
            fillColor: 'white',
            enabled: true,
            radius: -1,



        }
    },
         {
             name: 'Verizon',
             data: VerizonData,
             lineWidth: 0,
             marker: {
                 fillColor: 'C00000',
                 enabled: true,
                 radius: 7,

                 symbol: 'url(img/verizon-chart-icon.png)'
             },
             color: 'C00000'

         },
                 {
                     name: 'Net-Cable',
                     data: NetCabelData,
                     lineWidth: 0,
                     marker: {
                         fillColor: 'Green',
                         enabled: true,
                         radius: 6,
                         symbol: 'url(img/netcable-chart-icon.png)'
                     }, color: 'green'
                 }
        ]


    });
});
