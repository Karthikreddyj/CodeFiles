var dataCommercial = {
	monthAndYear: "JANUARY 2013"
	, cardTitle: "COMMERCIAL RECOGNITION"
	, cardLegend01: "OBSERVED"
	, cardLegend02: "MONTH PRIOR" 
	, items: [
		{
			color: "blue"
			, imgUrl: "commercials/Spiriva_Commercial1_170x100.png"
			, titleOfCommercial: "Commerical 1"
			, additionalInfo: "flowers and lady"
			, arrowIndicator: "neutral"
			, observedValue: "28%"
			, predictedValue: "-3%"
		}
		, {
			color: "green"
			, imgUrl: "commercials/Spiriva_Commercial2_170x100.png"
			, titleOfCommercial: "Commerical 2"
			, additionalInfo: "elephant in the office"
			, arrowIndicator: "up"
			, observedValue: "34%"
			, predictedValue: "+14%"
		}
		, {
			color: "red"
			, imgUrl: "commercials/Spiriva_Commercial1_170x100.png"
			, titleOfCommercial: "Commerical 3"
			, additionalInfo: "flowers and lady"
			, arrowIndicator: "down"
			, observedValue: "34%"
			, predictedValue: "-14%"
		}
		, {
		 	color: "blue"
		 	, imgUrl: "commercials/Spiriva_Commercial2_170x100.png"
		 	, titleOfCommercial: "Commerical 4"
		 	, additionalInfo: "elephant in the office"
		 	, arrowIndicator: "neutral"
		 	, observedValue: "28%"
		 	, predictedValue: "-3%"
		}		
	]
	, timePeriod: "Calendar Month (1/2/13 - 1/31/13)"
	, disclaimer: "Arrow indicates significant difference at a 95% level of confidence versus previous month"
}